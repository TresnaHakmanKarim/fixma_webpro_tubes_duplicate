<?php
/**
 * 
 */
class Site extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('all_model');
	}

	
	function index(){
		$this->load->view('site');
	}
}

?>