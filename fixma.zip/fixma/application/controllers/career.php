<?php
/**
 * 
 */
class Career extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('all_model');
	}

	
	function index(){
		$result['data'] = $this->all_model->getAllData('career')->result();
		$this->load->view('career/index', $result);
	}

	function store() {
		$data = array(
			'karir' => $this->input->post('karir'),
			'deskripsi_karir' => $this->input->post('deskripsi'),
			'update_karir' => $this->input->post('open'),
			'lokasi' => $this->input->post('lokasi')
		);

		$result = $this->all_model->insertData('career', $data);
		return redirect(base_url() . 'index.php/career/index');
	}

	function edit(){
		$condition = array('id_karir' => $this->input->get('id'));
    	$karir = $this->all_model->getDataByCondition('career', $condition)->row();
    	$data['career'] = $karir;
    	echo json_encode($data); 
	}

	function update(){
		$condition = array('id_karir' => $this->input->post('id_karir'));

    	$data = array(
			'karir' => $this->input->post('karir'),
			'deskripsi_karir' => $this->input->post('deskripsi'),
			'update_karir' => $this->input->post('open'),
			'lokasi' => $this->input->post('lokasi')
		);

		$result = $this->all_model->updateData('career', $condition, $data);
		return redirect(base_url() . 'index.php/career/index');
	}

	public function delete($id){
		$condition = array('id_karir' => $id);
		$res  = $this->all_model->deleteData("career", $condition);
		redirect(base_url() . "index.php/career/index");
	}
}

?>