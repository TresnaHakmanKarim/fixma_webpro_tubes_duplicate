<?php
/**
 * 
 */
class Partner extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('all_model');
	}

	
	function index(){
		$result['data'] = $this->all_model->getAllData('partner')->result();
		$this->load->view('partner/index', $result);
	}

	function store() {
		$data = array(
			'nama_partner' => $this->input->post('partner'),
			'deskripsi_partner' => $this->input->post('deskripsi')
		);

		$result = $this->all_model->insertData('partner', $data);
		return redirect(base_url() . 'penjualan/add');
	}

	function edit(){
		$condition = array('id_partner' => $this->input->get('id'));
    	$partner = $this->all_model->getDataByCondition('partner', $condition)->row();
    	$data['partner'] = $partner;
    	echo json_encode($data); 
	}

	function update(){
		$condition = array('id_partner' => $this->input->post('id_partner'));

    	$data = array(
			'nama_partner' => $this->input->post('partner'),
			'deskripsi_partner' => $this->input->post('deskripsi')
		);

		$result = $this->all_model->updateData('partner', $condition, $data);
		return redirect(base_url() . 'index.php/partner/edit');
	}

	public function delete($id){
		$condition = array('id_partner' => $id);
		$res  = $this->all_model->deleteData("partner", $condition);
		redirect(base_url() . "index.php/partner/index");
	}
}

?>