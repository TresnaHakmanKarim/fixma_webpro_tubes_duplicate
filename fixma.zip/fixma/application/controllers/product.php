<?php
/**
 * 
 */
class Product extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('all_model');
	}

	
	function index(){
		$result['data'] = $this->all_model->getAllData('product')->result();
		$this->load->view('product/index', $result);
	}

	function store() {
		$data = array(
			'nama_product' => $this->input->post('product'),
			'harga_product' => $this->input->post('harga_product'),
			'deskripsi_product' => $this->input->post('deskripsi')
		);

		$result = $this->all_model->insertData('product', $data);
		return redirect(base_url() . 'index.php/product/index');
	}

	function edit(){
		$condition = array('id_product' => $this->input->get('id'));
    	$partner = $this->all_model->getDataByCondition('product', $condition)->row();
    	$data['product'] = $partner;
    	echo json_encode($data); 
	}

	function update(){
		$condition = array('id_product' => $this->input->post('id_product'));

    	$data = array(
			'nama_product' => $this->input->post('product'),
			'harga_product' => $this->input->post('harga'),
			'deskripsi_product' => $this->input->post('deskripsi')
		);

		$result = $this->all_model->updateData('product', $condition, $data);
		return redirect(base_url() . 'index.php/product/index');
	}

	public function delete($id){
		$condition = array('id_product' => $id);
		$res  = $this->all_model->deleteData("product", $condition);
		redirect(base_url() . "index.php/product/index");
	}
}

?>