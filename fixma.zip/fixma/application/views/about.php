<?php
	$this->load->view('no_nav');
?>
<div class="container">
    <div class="row" style="margin-top: 15px;">
        <div class="col-md-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active" aria-current="page"><b>About DELL</b></li>
                </ol>
            </nav>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
    	<div class="col-md-12" style="margin-top: 20px;margin-bottom: 20px;">
	    	<p>
	    		Dell Technologies is committed to transforming businesses, shaping the future of innovation and developing technologies to drive human progress.
	    	</p>
	    	<p> 
	    	</p>
	    	<p> 
				Discover who we are, our family of brands, the leadership team and our strategic sponsorships to understand how Dell Technologies is powering the next technological revolution </p>
	    </div>
    	<div class="col-md-12" style="margin-top: 20px;margin-bottom: 20px;">
	        <table  class="table table-striped table-bordered" style="width:100%">
				<thead>
					<tr>
					  <th scope="col">Years</th>
					  <th scope="col">Increase</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>2018</td>
						<td>0.5 %</td>
					</tr>
					<tr>
						<td>2019</td>
						<td>1.5 %</td>
					</tr>
					<tr>
						<td>2020</td>
						<td>2 %</td>
					</tr>
					<tr>
						<td>2021</td>
						<td>2.5 %</td>
					</tr>
				</tbody>
			</table>
		</div>
    </div>
</div>

<?php
	$this->load->view('footer_main');
?>