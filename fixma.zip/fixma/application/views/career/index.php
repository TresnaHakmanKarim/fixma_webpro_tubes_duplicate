<?php
	$this->load->view('no_nav');
?>
<!--  -->
<div class="container">
    <div class="row" style="margin-top: 15px;">
        <div class="col-md-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active" aria-current="page"><b>Career</b></li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
    	<div class="col-md-12">
    		<button class="btn btn-primary add_karir">Add</button>
    	</div>
    	<div class="col-md-12" style="margin-top: 20px;margin-bottom: 20px;">
	        <table id="example" class="table table-striped table-bordered" style="width:100%">
				<thead>
					<tr>
					  <th scope="col">Career</th>
					  <th scope="col">Description</th>
					  <th scope="col">Open</th>
					  <th scope="col">Location</th>
					  <th scope="col"></th>
					</tr>
				</thead>
				<tbody>
					<?php
						foreach ($data as $key => $value) {
					?>
					<tr>
					  <td><?php echo $value->karir;?></td>
					  <td><?php echo $value->deskripsi_karir;?></td>
					  <td><?php echo $value->update_karir;?></td>
					  <td><?php echo $value->lokasi;?></td>
					  <td>
					  	<button class="btn btn-info view_karir" dataid="<?php echo $value->id_karir;?>">View</button>
					  	<button class="btn btn-warning edit_karir" style="color: #fff;" dataid="<?php echo $value->id_karir;?>">Edit</button>
					  	<a href="<?php echo base_url('index.php/career/delete/' . $value->id_karir);?>">
					  		<button class="btn btn-danger delete_karir" dataid="<?php echo $value->id_karir;?>">Delete</button>
					  	</a>
					  </td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
		</div>
    </div>
</div>

<div class="modal" id="add_modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      	<form method="post" action="<?php echo base_url('index.php/career/store');?>">
	      <div class="modal-header">
	        <h5 class="modal-title">Add</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	        <div class="form-group">
	        	<label>Career</label>
	        	<input type="text" name="karir" class="form-control">
	        </div>

	        <div class="form-group">
	        	<label>Description</label>
	        	<textarea class="form-control" name="deskripsi" cols="4" rows="5"></textarea>
	        </div>

	        <div class="form-group">
	        	<label>Open</label>
	        	<input type="text" name="open" class="form-control">
	        </div>

	        <div class="form-group">
	        	<label>Location</label>
	        	<input type="text" name="lokasi" class="form-control">
	        </div>
	      </div>
	      <div class="modal-footer">
	        <button type="submit" class="btn btn-primary">Save</button>
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	      </div>
  		</form>
    </div>
  </div>
</div>

<div class="modal" id="view_modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      	<form method="post" action="">
	      <div class="modal-header">
	        <h5 class="modal-title">View</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	        <div class="form-group">
	        	<label>Career</label>
	        	<input type="text" name="karir" class="form-control view_karir" disabled>
	        </div>

	        <div class="form-group">
	        	<label>Description</label>
	        	<textarea class="form-control view_deskripsi" name="deskripsi" cols="4" rows="5" disabled></textarea>
	        </div>

	         <div class="form-group">
	        	<label>Open</label>
	        	<input type="text" name="open" class="form-control view_open" disabled>
	        </div>
	      
	      	<div class="form-group">
	        	<label>Location</label>
	        	<input type="text" name="lokasi" class="form-control view_lokasi" disabled>
	        </div>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	      </div>
  		</form>
    </div>
  </div>
</div>

<div class="modal" id="edit_modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      	<form method="post" action="<?php echo base_url('index.php/career/update');?>">
	      <div class="modal-header">
	        <h5 class="modal-title">Edit</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	        <div class="form-group">
	        	<label>Career</label>
	        	<input type="text" name="karir" class="form-control edit_karir" value="">
	        </div>

	        <div class="form-group">
	        	<label>Description</label>
	        	<textarea class="form-control edit_deskripsi" name="deskripsi" cols="4" rows="5"></textarea>
	        </div>

	         <div class="form-group">
	        	<label>Open</label>
	        	<input type="text" name="open" class="form-control edit_open">
	        </div>
	      

	       <div class="form-group">
	        	<label>Location</label>
	        	<input type="text" name="lokasi" class="form-control edit_lokasi">
	        </div>
	      </div>

	      <div class="modal-footer">
	      	<button type="submit" class="btn btn-primary">Save</button>
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	      </div>
  		</form>
    </div>
  </div>
</div>

<?php
	$this->load->view('footer_main');
?>