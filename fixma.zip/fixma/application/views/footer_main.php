<!-- Footer -->
<footer class="text-light">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-6 col-xl-5">
                <label>Do more with Dell</label>
                <!-- <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25"> -->
                <p class="mb-0">
                    <a href="<?php echo base_url('index.php/partner/index')?>">
                        <u> Partner Program </u>
                      </a>
                </p>
            </div>

            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto">
                <label>Company Information</label>
                <!-- <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25"> -->
                <ul class="list-unstyled">
                    <li><a href="<?php echo base_url('index.php/about/index')?>">
                        <u> About Dell </u>
                    </a></li>
                    <li><a href="<?php echo base_url('index.php/product/index');?>">
                        <u> Product </u>
                    </a></li>
                    <li><a href="<?php echo base_url('index.php/career/index');?>">
                        <u> Career </u>
                    </a></li>
                </ul>
            </div>

            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto">
                <label>Legal</label>
                <!-- <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25"> -->
                <ul class="list-unstyled">
                    <li><a href="<?php echo base_url('index.php/site/index');?>">
                        <u> Site Terms </u>
                    </a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable();
        $('.add').click(function(){
            $('#add_modal').modal({backdrop: 'static', keyboard: true, show: true});
        });
        $('.edit_partner').click(function(){
            var id = $(this).attr('dataid'); //get the attribute value
            $.ajax({
              url : "<?php echo base_url();?>index.php/partner/edit",
              data:{id : id},
              method:'GET',
              dataType:'json',
              success:function(response) {
                console.log('response: ', response.partner);
                $('.edit_id_partner').val(response.partner.id_partner);
                $('.edit_partner').val(response.partner.nama_partner);
                $('.edit_deskripsi').text(response.partner.deskripsi_partner);
                $('#edit_modal').modal({backdrop: 'static', keyboard: true, show: true});
              }
            });
        });
        $('.view_partner').click(function(){
            var id = $(this).attr('dataid'); //get the attribute value
            $.ajax({
              url : "<?php echo base_url();?>index.php/partner/edit",
              data:{id : id},
              method:'GET',
              dataType:'json',
              success:function(response) {
                $('.view_partner').val(response.partner.nama_partner);
                $('.view_deskripsi').text(response.partner.deskripsi_partner);
                $('#view_modal').modal({backdrop: 'static', keyboard: true, show: true});
              }
            });
        });
        $('.edit_product').click(function(){
            var id = $(this).attr('dataid'); //get the attribute value
            $.ajax({
              url : "<?php echo base_url();?>index.php/product/edit",
              data:{id : id},
              method:'GET',
              dataType:'json',
              success:function(response) {
                console.log('response: ', response.product);
                $('.edit_id_product').val(response.product.id_product);
                $('.edit_product').val(response.product.nama_product);
                $('.edit_deskripsi_product').text(response.product.deskripsi_product);
                $('.edit_harga').val(response.product.harga_product);
                $('#edit_modal').modal({backdrop: 'static', keyboard: true, show: true});
              }
            });
        });
        $('.add_product').click(function(){
            $('#add_modal').modal({backdrop: 'static', keyboard: true, show: true});
        });
        $('.view_product').click(function(){
            var id = $(this).attr('dataid'); //get the attribute value
            $.ajax({
              url : "<?php echo base_url();?>index.php/product/edit",
              data:{id : id},
              method:'GET',
              dataType:'json',
              success:function(response) {
                $('.view_id_product').val(response.product.id_product);
                $('.view_product').val(response.product.nama_product);
                $('.view_deskripsi_product').text(response.product.deskripsi_product);
                $('.view_harga').val(response.product.harga_product);
                $('#view_modal').modal({backdrop: 'static', keyboard: true, show: true});
              }
            });
        });

        $('.edit_karir').click(function(){
            var id = $(this).attr('dataid'); //get the attribute value
            $.ajax({
              url : "<?php echo base_url();?>index.php/career/edit",
              data:{id : id},
              method:'GET',
              dataType:'json',
              success:function(response) {
                console.log('response: ', response.career);
                $('.edit_id_karir').val(response.career.id_karir);
                $('.edit_karir').val(response.career.karir);
                $('.edit_deskripsi').text(response.career.deskripsi_karir);
                $('.edit_open').val(response.career.update_karir);
                $('.edit_lokasi').val(response.career.lokasi);
                $('#edit_modal').modal({backdrop: 'static', keyboard: true, show: true});
              }
            });
        });
        $('.add_karir').click(function(){
            $('#add_modal').modal({backdrop: 'static', keyboard: true, show: true});
        });
        $('.view_karir').click(function(){
            var id = $(this).attr('dataid'); //get the attribute value
            $.ajax({
              url : "<?php echo base_url();?>index.php/career/edit",
              data:{id : id},
              method:'GET',
              dataType:'json',
              success:function(response) {
                $('.view_id_karir').val(response.career.id_karir);
                $('.view_karir').val(response.career.karir);
                $('.view_deskripsi').text(response.career.deskripsi_karir);
                $('.view_open').val(response.career.update_karir);
                $('.view_lokasi').val(response.career.lokasi);
                $('#view_modal').modal({backdrop: 'static', keyboard: true, show: true});
              }
            });
        });
        $('.image-link').magnificPopup({type:'image'});
    } );
</script>
</body>
</html>