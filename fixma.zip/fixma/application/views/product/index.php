<?php
	$this->load->view('no_nav');
?>
<div class="container">
    <div class="row" style="margin-top: 15px;">
        <div class="col-md-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active" aria-current="page"><b>Product</b></li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<div class="container">
	<div id="demo" class="carousel slide" data-ride="carousel" style="margin-top: 15px;margin-bottom: 20px;">

  <!-- Indicators -->
	  <ul class="carousel-indicators">
	    <li data-target="#demo" data-slide-to="0" class="active"></li>
	    <li data-target="#demo" data-slide-to="1"></li>
	    <li data-target="#demo" data-slide-to="2"></li>
	  </ul>


 <!--  slideshow  foto-->
	  <div class="carousel-inner">
	    <div class="carousel-item active">
	      <img src="<?php echo base_url('assets/image/produk2.jpg')?>" alt="Produk 2" style="width: 1150px; height: 500px;">
	    </div>
	    <div class="carousel-item">
	      <img src="<?php echo base_url('assets/image/produk1.jpg')?>" alt="Produk 1" style="width: 1150px; height: 500px;">
	    </div>
	    <div class="carousel-item">
	      <img src="<?php echo base_url('assets/image/produk3.jpg')?>"" alt="Produk 3" style="width: 1150px; height: 500px;">
	    </div>
	  </div>
	  	  <!-- Left and right controls -->
	  <a class="carousel-control-prev" href="#demo" data-slide="prev">
	    <span class="carousel-control-prev-icon"></span>
	  </a>
	  <a class="carousel-control-next" href="#demo" data-slide="next">
	    <span class="carousel-control-next-icon"></span>
	  </a>

	</div>
	</div>

<div class="container">
    <div class="row">
    	<div class="col-md-12">
    		<button class="btn btn-primary add_product">Add</button>
    	</div>
    	<div class="col-md-12" style="margin-top: 20px;margin-bottom: 20px;">
	        <table id="example" class="table table-striped table-bordered" style="width:100%">
				<thead>
					<tr>
					  <th scope="col">Product</th>
					  <th scope="col">Harga</th>
					  <th scope="col">Description</th>
					  <th scope="col"></th>
					</tr>
				</thead>
				<tbody>
					<?php
						foreach ($data as $key => $value) {
					?>
					<tr>
					  <td><?php echo $value->nama_product;?></td>
					  <td><?php echo $value->harga_product;?></td>
					  <td><?php echo $value->deskripsi_product;?></td>
					  <td>
					  	<button class="btn btn-info view_product" dataid="<?php echo $value->id_product;?>">View</button>
					  	<button class="btn btn-warning edit_product" style="color: #fff;" dataid="<?php echo $value->id_product;?>">Edit</button>
					  	<a href="<?php echo base_url('index.php/product/delete/' . $value->id_product);?>">
					  		<button class="btn btn-danger delete_product" dataid="<?php echo $value->id_product;?>">Delete</button>
					  	</a>
					  </td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
		</div>
    </div>
</div>

<div class="modal" id="add_modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      	<form method="post" action="<?php echo base_url('index.php/product/store');?>">
	      <div class="modal-header">
	        <h5 class="modal-title">Add</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	        <div class="form-group">
	        	<label>Product</label>
	        	<input type="text" name="product" class="form-control">
	        </div>

	        <div class="form-group">
	        	<label>Harga</label>
	        	<input type="text" name="harga_product" class="form-control">
	        </div>

	        <div class="form-group">
	        	<label>Description</label>
	        	<textarea class="form-control" name="deskripsi" cols="4" rows="5"></textarea>
	        </div>
	      </div>
	      <div class="modal-footer">
	        <button type="submit" class="btn btn-primary">Save</button>
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	      </div>
  		</form>
    </div>
  </div>
</div>

<div class="modal" id="view_modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      	<form method="post" action="">
	      <div class="modal-header">
	        <h5 class="modal-title">View</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	        <div class="form-group">
	        	<label>Product</label>
	        	<input type="text" name="product" class="form-control view_product" disabled>
	        </div>

	        <div class="form-group">
	        	<label>Harga</label>
	        	<input type="text" name="harga" class="form-control view_harga" disabled>
	        </div>

	        <div class="form-group">
	        	<label>Description</label>
	        	<textarea class="form-control view_deskripsi_product" name="deskripsi" cols="4" rows="5" disabled></textarea>
	        </div>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	      </div>
  		</form>
    </div>
  </div>
</div>

<div class="modal" id="edit_modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      	<form method="post" action="<?php echo base_url('index.php/product/update');?>">
	      <div class="modal-header">
	        <h5 class="modal-title">Edit</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	      	<input type="hidden" name="id_product" class="form-control edit_id_product" value="">

	        <div class="form-group">
	        	<label>Product</label>
	        	<input type="text" name="product" class="form-control edit_product" value="">
	        </div>

	        <div class="form-group">
	        	<label>Harga</label>
	        	<input type="text" name="harga" class="form-control edit_harga">
	        </div>

	        <div class="form-group">
	        	<label>Description</label>
	        	<textarea class="form-control edit_deskripsi_product" name="deskripsi" cols="4" rows="5"></textarea>
	        </div>
	      </div>
	      <div class="modal-footer">
	        <button type="submit" class="btn btn-primary">Save</button>
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	      </div>
  		</form>
    </div>
  </div>
</div>

<?php
	$this->load->view('footer_main');
?>