<?php
	$this->load->view('no_nav');
?>
<div class="container">
    <div class="row" style="margin-top: 15px;">
        <div class="col-md-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active" aria-current="page"><b>Site Terms</b></li>
                </ol>
            </nav>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
    	<div class="col-md-12" style="margin-top: 20px;margin-bottom: 20px;">
	    	<p>
	    		This site is protected by applicable copyrights. If someone is plagiarism and impersonating the website, it will be given as below.
	    	</p>
	    </div>
    	<div class="col-md-12" style="margin-top: 20px;margin-bottom: 20px;">
	        <table  class="table table-striped table-bordered" style="width:100%">
				<thead>
					<tr>
					  <th scope="col">Punishment</th>
					  <th scope="col">Compensation</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>3 Years</td>
						<td>100.000.000</td>
					</tr>
					<tr>
						<td>5 Years</td>
						<td>50.000.000</td>
					</tr>
				</tbody>
			</table>
		</div>
    </div>
</div>

<?php
	$this->load->view('footer_main');
?>