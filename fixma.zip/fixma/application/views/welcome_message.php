<?php
    $this->load->view('header');
?>
    <nav class="navbar navbar-expand-md navbar-dark bg-primary">
        <a class="navbar-brand" href="<?php echo base_url();?>">
            <img src="<?php echo base_url('assets/image/dellogo.png');?>" style="width:100px;">
        </a>
    </nav>
    <div class="row" style="margin-left: 15px;margin-bottom: 35px;margin-top: 15px;">
        <div class="col-md-10" style="margin-bottom: 30px;margin-left: 3px;">
            <div>
                <img src="<?php echo base_url('assets/image/welcomee.jpg');?>" width= "930" height="380" style="width: 100%;margin-left: 50px;">
            </div>
        </div>

        <div class="container" style="margin: auto;">
            <table class="table table-borderless table-dark">
              <thead>
                <tr>
                  <td scope="col">Do more with Dell</td>
                  <td>Company Information</td>
                  <td>Legal</td>
                  <!-- <td>Comunity</td> -->
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td rowspan="3">
                      <a href="<?php echo base_url('index.php/partner/index')?>" class="text-white">
                        <u> Partner Program </u>
                      </a>
                  </td>
                  <td>
                    <a href="<?php echo base_url('index.php/about/index')?>" class="text-white">
                        <u> About Dell </u>
                    </a>
                  </td>
                  <td>
                    <a href="<?php echo base_url('index.php/site/index');?>" class="text-white">
                        <u> Site Terms </u>
                    </a>
                  </td>
                 <!--  <td>
                    <a href="<?php echo base_url('index.php/blog/index');?>">
                        <u> Read Our Blog</u>
                    </a>
                  </td> -->
                </tr>
                <tr>
                  <td>
                    <a href="<?php echo base_url('index.php/product/index');?>" class="text-white">
                        <u> Product </u>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td>
                    <a href="<?php echo base_url('index.php/career/index');?>" class="text-white">
                        <u> Career</u>
                    </a>
                  </td>
                </tr>
              </tbody>
            </table>
        </div>
    </div>
    <!-- <div class="row" style="margin-left: 3px;margin-bottom: 35px;margin-top: 15px;">
        <div class="col-md-2" style="margin-left: 15px;">
            <div>Do more with Digital Recruiting Academy</div>
            <div>
                <a href="<?php echo base_url("partner/index.php");?>">
                    <u>Partner Program</u>
                </a>
            </div>
        </div>
        <div class="col-md-2">
            <div>Do more with Digital Recruiting Academy</div>
        </div>
        <div class="col-md-2">
            <div>Do more with Digital Recruiting Academy</div>
        </div>
        <div class="col-md-2">
            <div>Do more with Digital Recruiting Academy</div>
        </div>
    </div> -->
</div>
<?php 
   $this->load->view('footer');
?>

